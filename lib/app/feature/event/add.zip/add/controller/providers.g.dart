// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$dayHash() => r'fed0939ee958d485d8842c31875548bf269e7f6e';

/// See also [Day].
@ProviderFor(Day)
final dayProvider = AutoDisposeNotifierProvider<Day, DateTime?>.internal(
  Day.new,
  name: r'dayProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$dayHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$Day = AutoDisposeNotifier<DateTime?>;
String _$hourSelectedHash() => r'ac9f6924cf550d400185badcdf9b60f80717684c';

/// See also [HourSelected].
@ProviderFor(HourSelected)
final hourSelectedProvider =
    AutoDisposeNotifierProvider<HourSelected, HourModel?>.internal(
  HourSelected.new,
  name: r'hourSelectedProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$hourSelectedHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$HourSelected = AutoDisposeNotifier<HourModel?>;
String _$roomSelectedHash() => r'7ff4c5a83d06abd590c737b6f0a4c873d4e79433';

/// See also [RoomSelected].
@ProviderFor(RoomSelected)
final roomSelectedProvider =
    AutoDisposeNotifierProvider<RoomSelected, RoomModel?>.internal(
  RoomSelected.new,
  name: r'roomSelectedProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$roomSelectedHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$RoomSelected = AutoDisposeNotifier<RoomModel?>;
String _$attendancesOriginalHash() =>
    r'91f0263b278939a1e113bb60e4986a70d283f0a0';

/// See also [AttendancesOriginal].
@ProviderFor(AttendancesOriginal)
final attendancesOriginalProvider = AutoDisposeNotifierProvider<
    AttendancesOriginal, List<AttendanceModel>>.internal(
  AttendancesOriginal.new,
  name: r'attendancesOriginalProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$attendancesOriginalHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AttendancesOriginal = AutoDisposeNotifier<List<AttendanceModel>>;
String _$attendancesSelectedHash() =>
    r'469b7a43bf58e45f2945f744f235b20113addf2b';

/// See also [AttendancesSelected].
@ProviderFor(AttendancesSelected)
final attendancesSelectedProvider = AutoDisposeNotifierProvider<
    AttendancesSelected, List<AttendanceModel>>.internal(
  AttendancesSelected.new,
  name: r'attendancesSelectedProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$attendancesSelectedHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AttendancesSelected = AutoDisposeNotifier<List<AttendanceModel>>;
String _$eventFormHash() => r'1892366dbd8f2a9fd44b62619d93218d8222d6f2';

/// See also [EventForm].
@ProviderFor(EventForm)
final eventFormProvider =
    AutoDisposeNotifierProvider<EventForm, EventFormState>.internal(
  EventForm.new,
  name: r'eventFormProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$eventFormHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$EventForm = AutoDisposeNotifier<EventFormState>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
