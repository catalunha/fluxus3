// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$eventReadHash() => r'30ab37f4ae1e1970ad11471d15ac8ac716b418c5';

/// Copied from Dart SDK
class _SystemHash {
  _SystemHash._();

  static int combine(int hash, int value) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + value);
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x0007ffff & hash) << 10));
    return hash ^ (hash >> 6);
  }

  static int finish(int hash) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x03ffffff & hash) << 3));
    // ignore: parameter_assignments
    hash = hash ^ (hash >> 11);
    return 0x1fffffff & (hash + ((0x00003fff & hash) << 15));
  }
}

typedef EventReadRef = AutoDisposeFutureProviderRef<EventModel?>;

/// See also [eventRead].
@ProviderFor(eventRead)
const eventReadProvider = EventReadFamily();

/// See also [eventRead].
class EventReadFamily extends Family<AsyncValue<EventModel?>> {
  /// See also [eventRead].
  const EventReadFamily();

  /// See also [eventRead].
  EventReadProvider call({
    required String? id,
  }) {
    return EventReadProvider(
      id: id,
    );
  }

  @override
  EventReadProvider getProviderOverride(
    covariant EventReadProvider provider,
  ) {
    return call(
      id: provider.id,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'eventReadProvider';
}

/// See also [eventRead].
class EventReadProvider extends AutoDisposeFutureProvider<EventModel?> {
  /// See also [eventRead].
  EventReadProvider({
    required this.id,
  }) : super.internal(
          (ref) => eventRead(
            ref,
            id: id,
          ),
          from: eventReadProvider,
          name: r'eventReadProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$eventReadHash,
          dependencies: EventReadFamily._dependencies,
          allTransitiveDependencies: EventReadFamily._allTransitiveDependencies,
        );

  final String? id;

  @override
  bool operator ==(Object other) {
    return other is EventReadProvider && other.id == id;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, id.hashCode);

    return _SystemHash.finish(hash);
  }
}

String _$dayHash() => r'fed0939ee958d485d8842c31875548bf269e7f6e';

/// See also [Day].
@ProviderFor(Day)
final dayProvider = AutoDisposeNotifierProvider<Day, DateTime?>.internal(
  Day.new,
  name: r'dayProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$dayHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$Day = AutoDisposeNotifier<DateTime?>;
String _$hourSelectedHash() => r'ac9f6924cf550d400185badcdf9b60f80717684c';

/// See also [HourSelected].
@ProviderFor(HourSelected)
final hourSelectedProvider =
    AutoDisposeNotifierProvider<HourSelected, HourModel?>.internal(
  HourSelected.new,
  name: r'hourSelectedProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$hourSelectedHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$HourSelected = AutoDisposeNotifier<HourModel?>;
String _$roomSelectedHash() => r'7ff4c5a83d06abd590c737b6f0a4c873d4e79433';

/// See also [RoomSelected].
@ProviderFor(RoomSelected)
final roomSelectedProvider =
    AutoDisposeNotifierProvider<RoomSelected, RoomModel?>.internal(
  RoomSelected.new,
  name: r'roomSelectedProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$roomSelectedHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$RoomSelected = AutoDisposeNotifier<RoomModel?>;
String _$statusSelectedHash() => r'5c3bf13893d2e58c1f8b032b250305864cba06fe';

/// See also [StatusSelected].
@ProviderFor(StatusSelected)
final statusSelectedProvider =
    AutoDisposeNotifierProvider<StatusSelected, StatusModel?>.internal(
  StatusSelected.new,
  name: r'statusSelectedProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$statusSelectedHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$StatusSelected = AutoDisposeNotifier<StatusModel?>;
String _$attendancesOriginalHash() =>
    r'91f0263b278939a1e113bb60e4986a70d283f0a0';

/// See also [AttendancesOriginal].
@ProviderFor(AttendancesOriginal)
final attendancesOriginalProvider = AutoDisposeNotifierProvider<
    AttendancesOriginal, List<AttendanceModel>>.internal(
  AttendancesOriginal.new,
  name: r'attendancesOriginalProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$attendancesOriginalHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AttendancesOriginal = AutoDisposeNotifier<List<AttendanceModel>>;
String _$attendancesSelectedHash() =>
    r'f30081865c73997c0b0287f005010b84d9c2eee0';

/// See also [AttendancesSelected].
@ProviderFor(AttendancesSelected)
final attendancesSelectedProvider = AutoDisposeNotifierProvider<
    AttendancesSelected, List<AttendanceModel>>.internal(
  AttendancesSelected.new,
  name: r'attendancesSelectedProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$attendancesSelectedHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AttendancesSelected = AutoDisposeNotifier<List<AttendanceModel>>;
String _$eventFormHash() => r'a904e9b9a710f8db3788d64899168754bf03fedb';

/// See also [EventForm].
@ProviderFor(EventForm)
final eventFormProvider =
    AutoDisposeNotifierProvider<EventForm, EventFormState>.internal(
  EventForm.new,
  name: r'eventFormProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$eventFormHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$EventForm = AutoDisposeNotifier<EventFormState>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
