// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'states.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$AttendanceFormState {
  AttendanceFormStatus get status => throw _privateConstructorUsedError;
  String get error => throw _privateConstructorUsedError;
  AttendanceModel? get model => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $AttendanceFormStateCopyWith<AttendanceFormState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AttendanceFormStateCopyWith<$Res> {
  factory $AttendanceFormStateCopyWith(
          AttendanceFormState value, $Res Function(AttendanceFormState) then) =
      _$AttendanceFormStateCopyWithImpl<$Res, AttendanceFormState>;
  @useResult
  $Res call(
      {AttendanceFormStatus status, String error, AttendanceModel? model});

  $AttendanceModelCopyWith<$Res>? get model;
}

/// @nodoc
class _$AttendanceFormStateCopyWithImpl<$Res, $Val extends AttendanceFormState>
    implements $AttendanceFormStateCopyWith<$Res> {
  _$AttendanceFormStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? error = null,
    Object? model = freezed,
  }) {
    return _then(_value.copyWith(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as AttendanceFormStatus,
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
      model: freezed == model
          ? _value.model
          : model // ignore: cast_nullable_to_non_nullable
              as AttendanceModel?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $AttendanceModelCopyWith<$Res>? get model {
    if (_value.model == null) {
      return null;
    }

    return $AttendanceModelCopyWith<$Res>(_value.model!, (value) {
      return _then(_value.copyWith(model: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_AttendanceFormStateCopyWith<$Res>
    implements $AttendanceFormStateCopyWith<$Res> {
  factory _$$_AttendanceFormStateCopyWith(_$_AttendanceFormState value,
          $Res Function(_$_AttendanceFormState) then) =
      __$$_AttendanceFormStateCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {AttendanceFormStatus status, String error, AttendanceModel? model});

  @override
  $AttendanceModelCopyWith<$Res>? get model;
}

/// @nodoc
class __$$_AttendanceFormStateCopyWithImpl<$Res>
    extends _$AttendanceFormStateCopyWithImpl<$Res, _$_AttendanceFormState>
    implements _$$_AttendanceFormStateCopyWith<$Res> {
  __$$_AttendanceFormStateCopyWithImpl(_$_AttendanceFormState _value,
      $Res Function(_$_AttendanceFormState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? error = null,
    Object? model = freezed,
  }) {
    return _then(_$_AttendanceFormState(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as AttendanceFormStatus,
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
      model: freezed == model
          ? _value.model
          : model // ignore: cast_nullable_to_non_nullable
              as AttendanceModel?,
    ));
  }
}

/// @nodoc

class _$_AttendanceFormState implements _AttendanceFormState {
  _$_AttendanceFormState(
      {this.status = AttendanceFormStatus.initial,
      this.error = '',
      this.model});

  @override
  @JsonKey()
  final AttendanceFormStatus status;
  @override
  @JsonKey()
  final String error;
  @override
  final AttendanceModel? model;

  @override
  String toString() {
    return 'AttendanceFormState(status: $status, error: $error, model: $model)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_AttendanceFormState &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.error, error) || other.error == error) &&
            (identical(other.model, model) || other.model == model));
  }

  @override
  int get hashCode => Object.hash(runtimeType, status, error, model);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_AttendanceFormStateCopyWith<_$_AttendanceFormState> get copyWith =>
      __$$_AttendanceFormStateCopyWithImpl<_$_AttendanceFormState>(
          this, _$identity);
}

abstract class _AttendanceFormState implements AttendanceFormState {
  factory _AttendanceFormState(
      {final AttendanceFormStatus status,
      final String error,
      final AttendanceModel? model}) = _$_AttendanceFormState;

  @override
  AttendanceFormStatus get status;
  @override
  String get error;
  @override
  AttendanceModel? get model;
  @override
  @JsonKey(ignore: true)
  _$$_AttendanceFormStateCopyWith<_$_AttendanceFormState> get copyWith =>
      throw _privateConstructorUsedError;
}
