// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$attendanceReadHash() => r'982079cfbaefe57f0cb94e135e9692c5ce09b396';

/// Copied from Dart SDK
class _SystemHash {
  _SystemHash._();

  static int combine(int hash, int value) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + value);
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x0007ffff & hash) << 10));
    return hash ^ (hash >> 6);
  }

  static int finish(int hash) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x03ffffff & hash) << 3));
    // ignore: parameter_assignments
    hash = hash ^ (hash >> 11);
    return 0x1fffffff & (hash + ((0x00003fff & hash) << 15));
  }
}

typedef AttendanceReadRef = AutoDisposeFutureProviderRef<AttendanceModel?>;

/// See also [attendanceRead].
@ProviderFor(attendanceRead)
const attendanceReadProvider = AttendanceReadFamily();

/// See also [attendanceRead].
class AttendanceReadFamily extends Family<AsyncValue<AttendanceModel?>> {
  /// See also [attendanceRead].
  const AttendanceReadFamily();

  /// See also [attendanceRead].
  AttendanceReadProvider call({
    required String? id,
  }) {
    return AttendanceReadProvider(
      id: id,
    );
  }

  @override
  AttendanceReadProvider getProviderOverride(
    covariant AttendanceReadProvider provider,
  ) {
    return call(
      id: provider.id,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'attendanceReadProvider';
}

/// See also [attendanceRead].
class AttendanceReadProvider
    extends AutoDisposeFutureProvider<AttendanceModel?> {
  /// See also [attendanceRead].
  AttendanceReadProvider({
    required this.id,
  }) : super.internal(
          (ref) => attendanceRead(
            ref,
            id: id,
          ),
          from: attendanceReadProvider,
          name: r'attendanceReadProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$attendanceReadHash,
          dependencies: AttendanceReadFamily._dependencies,
          allTransitiveDependencies:
              AttendanceReadFamily._allTransitiveDependencies,
        );

  final String? id;

  @override
  bool operator ==(Object other) {
    return other is AttendanceReadProvider && other.id == id;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, id.hashCode);

    return _SystemHash.finish(hash);
  }
}

String _$authorizationDateCreateHash() =>
    r'36bba6b986e5c14a379277491010fbae8534a83b';

/// See also [AuthorizationDateCreate].
@ProviderFor(AuthorizationDateCreate)
final authorizationDateCreateProvider =
    AutoDisposeNotifierProvider<AuthorizationDateCreate, DateTime?>.internal(
  AuthorizationDateCreate.new,
  name: r'authorizationDateCreateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$authorizationDateCreateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AuthorizationDateCreate = AutoDisposeNotifier<DateTime?>;
String _$authorizationDateLimitHash() =>
    r'3fd2451b654ad37d8346f76ea492e3e28a803f6d';

/// See also [AuthorizationDateLimit].
@ProviderFor(AuthorizationDateLimit)
final authorizationDateLimitProvider =
    AutoDisposeNotifierProvider<AuthorizationDateLimit, DateTime?>.internal(
  AuthorizationDateLimit.new,
  name: r'authorizationDateLimitProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$authorizationDateLimitHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AuthorizationDateLimit = AutoDisposeNotifier<DateTime?>;
String _$professionalSelectedHash() =>
    r'8025c9586383a028e2b1ba81bc44cb6cb867d77c';

/// See also [ProfessionalSelected].
@ProviderFor(ProfessionalSelected)
final professionalSelectedProvider = AutoDisposeNotifierProvider<
    ProfessionalSelected, UserProfileModel?>.internal(
  ProfessionalSelected.new,
  name: r'professionalSelectedProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$professionalSelectedHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ProfessionalSelected = AutoDisposeNotifier<UserProfileModel?>;
String _$proceduresHash() => r'08ded89464c091f1f7bebb0b6d3b6dc590c55baa';

/// See also [Procedures].
@ProviderFor(Procedures)
final proceduresProvider =
    AutoDisposeNotifierProvider<Procedures, List<ProcedureModel>>.internal(
  Procedures.new,
  name: r'proceduresProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$proceduresHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$Procedures = AutoDisposeNotifier<List<ProcedureModel>>;
String _$patientSelectedHash() => r'aed4dc7ba217943f3833d691cfea31d6c8da1fa5';

/// See also [PatientSelected].
@ProviderFor(PatientSelected)
final patientSelectedProvider =
    AutoDisposeNotifierProvider<PatientSelected, PatientModel?>.internal(
  PatientSelected.new,
  name: r'patientSelectedProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$patientSelectedHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$PatientSelected = AutoDisposeNotifier<PatientModel?>;
String _$healthPlansHash() => r'ac4cce369aed6994049f8404d25be6b3199cf956';

/// See also [HealthPlans].
@ProviderFor(HealthPlans)
final healthPlansProvider =
    AutoDisposeNotifierProvider<HealthPlans, List<HealthPlanModel>>.internal(
  HealthPlans.new,
  name: r'healthPlansProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$healthPlansHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$HealthPlans = AutoDisposeNotifier<List<HealthPlanModel>>;
String _$attendanceFormHash() => r'0c04f35c2ed68d85cdbb98b6c4307403fabfc5d0';

/// See also [AttendanceForm].
@ProviderFor(AttendanceForm)
final attendanceFormProvider =
    AutoDisposeNotifierProvider<AttendanceForm, AttendanceFormState>.internal(
  AttendanceForm.new,
  name: r'attendanceFormProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$attendanceFormHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AttendanceForm = AutoDisposeNotifier<AttendanceFormState>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
